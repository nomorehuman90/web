#보안상 중요한 값이나 기능들을 모아둔 파일

from datetime import datetime, timedelta , timezone
import jwt
from app.core.config import settings

def createToken(userId : str ):
    payload = {
        "sub" : userId,
        "exp" : datetime.now(timezone.utc) + timedelta(minutes=30),
    }

    print(settings.SECRET_KEY)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

#토큰 확인하는 함수
#토큰에서 원하는 갑승ㄹ 가져오는 함수
#비밀번호를 암호화 하는 함수
#비밀번호 확인
