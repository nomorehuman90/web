from fastapi import FastAPI

from app.api.routers import board, user
from app.db.database import Base, engine
from app.models.board import Board
from app.models.user import User

app = FastAPI(title="노트 API", version="0.1.0")
app.include_router(user.router)
app.include_router(board.router)
Base.metadata.create_all(engine)


@app.get("/")
def main():
    return {"message": "노트 API 서버입니다."}
